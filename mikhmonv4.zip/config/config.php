<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<mikhmon','mikhmon>|>aWNlbA==');
$data['SERVERLOROKAN'] = array ('1'=>'SERVERLOROKAN!103.93.93.254:2026','SERVERLOROKAN@|@owner','SERVERLOROKAN#|#a6tyqmJqaGc=','SERVERLOROKAN%DBN Hotspot 1','SERVERLOROKAN^hotspot.dbn.net','SERVERLOROKAN&Rp','SERVERLOROKAN*','SERVERLOROKAN(','SERVERLOROKAN)','SERVERLOROKAN=30','SERVERLOROKAN@!@disable','SERVERLOROKAN#!#');